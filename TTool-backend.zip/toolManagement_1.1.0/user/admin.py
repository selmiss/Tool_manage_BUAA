from django.contrib import admin

from user.models import *
# Register your models here.