from django.contrib import admin
from user.models import *
# Register your models here.
admin.site.register([User])