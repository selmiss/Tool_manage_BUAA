<template>
  <div class="about">
    <h1>This is an about page</h1>
    <el-button type="primary">lalal</el-button>
  </div>
</template>
