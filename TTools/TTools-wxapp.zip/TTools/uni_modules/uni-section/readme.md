## Section 标题栏
> **组件名：uni-section**
> 代码块： `uSection`

uni-section 组件主要用于文章、列表详情等标题展示

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-section)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839
