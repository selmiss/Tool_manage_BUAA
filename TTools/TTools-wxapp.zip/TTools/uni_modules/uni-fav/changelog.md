## 1.2.1（2022-05-30）
- 新增 stat 属性 ，是否开启uni统计功能
## 1.2.0（2021-11-19）
- 优化 组件UI，并提供设计资源，详见:[https://uniapp.dcloud.io/component/uniui/resource](https://uniapp.dcloud.io/component/uniui/resource)
- 文档迁移，详见:[https://uniapp.dcloud.io/component/uniui/uni-fav](https://uniapp.dcloud.io/component/uniui/uni-fav)
## 1.1.1（2021-08-24）
- 新增 支持国际化
## 1.1.0（2021-07-13）
- 组件兼容 vue3，如何创建vue3项目，详见 [uni-app 项目支持 vue3 介绍](https://ask.dcloud.net.cn/article/37834)
## 1.0.6（2021-05-12）
- 新增 组件示例地址
## 1.0.5（2021-04-21）
- 优化 添加依赖 uni-icons, 导入后自动下载依赖
## 1.0.4（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件
## 1.0.3（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件
## 1.0.2（2021-02-05）
- 调整为uni_modules目录规范
